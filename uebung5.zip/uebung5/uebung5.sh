#!/bin/bash
java -jar BrainfuckInterpreter.jar

mkdir src/java/general
mkdir src/java/uebungen
mkdir src/java/uebungen/uebungsblatt5

cd src/java

mv RandomValue.java general/RandomValue.java
mv Adresse7.java uebungen/uebungsblatt5/Adresse7.java
mv AdressException.java uebungen/uebungsblatt5/AdressException.java
mv Hochschulperson7.java uebungen/uebungsblatt5/Hochschulperson7.java
mv Ort.java uebungen/uebungsblatt5/Ort.java
mv Person.java uebungen/uebungsblatt5/Person.java
mv Professor7.java uebungen/uebungsblatt5/Professor7.java
mv Student7.java uebungen/uebungsblatt5/Student7.java
mv Studiengruppe.java uebungen/uebungsblatt5/Studiengruppe.java

javac general/RandomValue.java
javac uebungen/uebungsblatt5/*.java
javac Uebung7.java

java Uebung7

rm Uebung7.java
rm Uebung7.class
rm -r general
rm -r uebungen

cd ../../
