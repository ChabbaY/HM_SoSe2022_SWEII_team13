<h1>
    SWE II SS 2022
</h1>

<hr/>

<h2>
    <i>Übungsblatt 5</i>
</h2>

<h3> Windows (cmd) </h3>
Eingabeaufforderung oder Powershell in aktuellem Ordner öffnen, dann:<br/>
<pre>	uebung5.bat</pre>

<h3> Unix-based (bash) </h3>
beliebige Shell in aktuellem Ordner öffnen, dann:<br/>
<pre>	bash uebung5.sh</pre>

<h3> Java Code </h3>
Java Code wird nach Ausführung wieder gelöscht. Wenn das nicht gewünscht ist: Auskommentieren,<br/>
uebung5.bat (Z 25 - 28) durch ::<br/>
uebung5.sh (Z 26 - 29) durch #

<h3> Quellcode </h3>
Jeglicher Quellcode liegt als brainfuck (.bf) vor, wird vom BrainfuckInterpreter kompiliert und ausgeführt.
Dabei werden in src/java/ temporäre Dateien angelegt.

<h3> Version </h3>
Es wird mindestens Java-Version <b>17.0.3</b> (Build 62) benötigt. Dies sollte aber kein Problem sein,
da bereits jdk 18 zum Download bereitsteht. Alternativ kann der brainfuck code auch manuell übersetzt werden.
Dies ist allerdings nicht zu empfehlen.

<hr/>

Diese Datei ist geeignet für eine Darstellung im Webbrowser